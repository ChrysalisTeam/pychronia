$(document).ready(function() {
    $('.viewcode-link').parents('a').attr('target', '_blank');
    $('a.extenal').attr('target', '_blank');
});
